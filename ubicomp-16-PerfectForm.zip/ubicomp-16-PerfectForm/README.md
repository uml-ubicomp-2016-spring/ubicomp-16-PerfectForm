# ubicomp-16-PerfectForm
RunningBuddy Ubicomp Project

Update #0
This app will overall help the runner from preparing for your run until the run is over. The app will help the runner figure out what to wear based on the weather amongst other tasks. Ideas so far

1. Light sensor will warn user too late to run or to wear refelective material
2. Step sensor will count steps per minute (180 steps/min is the recommended amount for a jog pace) 
3. Weather/Location services to help tell runner decide what to wear
4. Gyroscope to detect if arms are parrallel to body 
5. Accelerometer readings will be used to detect if the user is exerting too much energy with needless arm motion

Pre-Update #1
Ronald Manganaro: working on light sensor 
Paul: Working on weather service to download JSON data
Curtis: pending
Bobby: light sensor 
